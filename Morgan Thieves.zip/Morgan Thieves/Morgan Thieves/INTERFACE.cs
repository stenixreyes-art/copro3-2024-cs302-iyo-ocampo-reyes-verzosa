﻿namespace Morgan_Thieves
{
    internal interface INTERFACE
    {
        public interface INTERFACE
        {
            void Display();
        }
    }
}