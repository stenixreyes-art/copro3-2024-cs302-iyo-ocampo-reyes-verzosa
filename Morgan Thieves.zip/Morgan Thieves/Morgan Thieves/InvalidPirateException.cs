﻿namespace Morgan_Thieves
{
    internal class InvalidPirateException : Exception
    {
        public InvalidPirateException(string message) : base(message)
        {

        }
    }
}